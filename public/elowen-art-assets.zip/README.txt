Elowen's Last Stand — current artwork

forest.png: bridge and forest background used at the crossing.
elowen.png: current Elowen character artwork (transparent PNG).
characters.png: original character sheet; the three zombie sections are used in the game. The original heroine section is superseded by elowen.png.

These are source images. The game trims and scales the characters for display.
Town, grasslands and river-road scenery is currently drawn in code, rather than stored as separate background images.
