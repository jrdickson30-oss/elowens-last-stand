Elowen's Last Stand — current artwork

forest.png: bridge and forest background used at the crossing.
elowen-idle/: current six-frame idle animation, supplied by the user. The spritesheet has six 192 x 208 pixel cells, each shown for 220 ms. It faces right and is mirrored for left-facing poses. Files include the metadata, animated GIF preview and individual PNG frames.
Elowen-idle-assets.zip: unchanged original upload.
elowen.png: earlier static Elowen artwork, retained as a fallback/reference.
characters.png: original character sheet; the three zombie sections are used in the game. Its original heroine section is superseded by the current Elowen artwork.

The game displays Elowen at 96 pixels high and uses the first idle pose for movement/combat until more animations are available.
Town, grasslands and river-road scenery is currently drawn in code, rather than stored as separate background images.
